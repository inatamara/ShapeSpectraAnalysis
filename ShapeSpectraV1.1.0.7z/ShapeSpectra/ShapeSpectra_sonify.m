%% this scripts converts the resampled cellular outlines RhoRes to the sound
% load the ShapeSpectra_SampleData_CURV.mat file first

% this script is associated with article:  Pectin homogalacturonan nanofilament expansion drives morphogenesis in
% plant epidermal cells, Haas et al., Science 2020. DOI: 10.1126/science.aaz5103
% To acknowledge its use, please cite the above article
icell = 14; % select a cell id to sonify
% npres(icell)
wavplay = [];
fac = 140;
for iday = 1:3 % loop over days
    wav = rhoRes{icell}(:,iday)-min(rhoRes{icell}(:,iday));
    wav = 2*wav/max(wav)-1; % Matlab needs to scale between -1 and 1
    wavplay = vertcat(wavplay,repmat(wav,[fac,1]));
end
%
fr = 80000; % chose the sampling frequency, that will change audible the pitch
sound(wavplay,fr);
%%
audiowrite(strcat('cell_',num2str(icell),'.wav'),wavplay,fr)
function rhoRes = rhoResample(rho,varargin)
% This is the subfunction called by ShapeSpectra function
%   it will resample the number of elements in first and second element of
%   rho cell array according to the number of points in the third element
%   of rho 
% this function is associated with article:  Pectin homogalacturonan nanofilament expansion drives morphogenesis in
% plant epidermal cells, Haas et al., Science 2020. DOI: 10.1126/science.aaz5103


if nargin == 1
x1 = rho{1};
x2 = rho{2};
x3 = rho{3};

p = numel(x1);
q = numel(x2);
r = numel(x3);

y1 = resample(x1-x1(1),r,p) + x1(1);
y2 = resample(x2-x2(1),r,q) + x2(1);
% figure;
% 
% plot(1:numel(y1),y1,'-b')
% hold on
% plot(1:numel(y2),y2,'-g')
% plot(1:numel(x3),x3,'-r')
rhoRes = [y1,y2,x3];
elseif nargin == 2
    
x1 = varargin{1};
x3 = rho;

p = numel(x1);
r = numel(x3);

y1 = resample(x1-x1(1),r,p) + x1(1);
rhoRes = y1;  
end
end


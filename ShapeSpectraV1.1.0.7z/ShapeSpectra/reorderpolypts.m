% this is the script used by ShapeSpectra family functions. 
% figure
cimean = mean(ci);
rimean = mean(ri);
angles = atan2( (ri-rimean),(ci-cimean));
[sortedAngles, sortIndices] = sort(angles);
reorderedci = ci(sortIndices);
reorderedri = ri(sortIndices);
% plot(reorderedci, reorderedri, 'bo-');
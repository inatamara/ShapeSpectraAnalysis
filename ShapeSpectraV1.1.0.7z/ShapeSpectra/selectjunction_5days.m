function [reorderjunc,conhull,cent] = selectjunction_5days(datatrack,L,skel,branchloc,a,day)
% this is the subfunction used by ShapeSpectra family functions. It is sued
% to reorder tre tri-cellular vertices after manualy adding new vertices
ntr = size(datatrack,1);
flag = 0;
for ii = 1:ntr
    icell = datatrack(ii,day);

    % find all branchponts in skeleton for all cells
    tmp = L == icell;
    Ls = bwlabel(~skel,4); % skeletonize
    flag = flag+1;
    struct  = regionprops(tmp,'BoundingBox', 'Centroid');
    % find region in skeleton corresponding to icell in L
    structtest  = regionprops(Ls,'Centroid');
    centers = cat(1,structtest.Centroid);
    cent{flag} = cat(1,struct.Centroid);
    D = pdist2(struct.Centroid,centers);
    [~,indD] = min(D);
    tmp1 = Ls == indD;

    b2 = imdilate(tmp1, ones(a,a)) & branchloc; % branch points of icell
    [ri,ci] = find(b2 & branchloc);
    if numel(ri) >=1
        
        reorderpolypts
        conhull{flag}(:,:) = poly2mask(reorderedci,reorderedri,size(L,1),size(L,2));
        reorderjunc{flag}(:,1) = reorderedci;
        reorderjunc{flag}(:,2) = reorderedri;
    end

    
end

end


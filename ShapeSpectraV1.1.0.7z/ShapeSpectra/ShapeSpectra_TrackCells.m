% this semiauthomatic script will track cells in up to 5 different images
% Tracking is performed in pairs of images (e.g. day 3 with day 2, etc) and then 
% only cells identified in all the images are kept
% It is semi-automated; it requires user to select the same 4-12 (or more for some
% images) cells in two images. it will then calculate the transform based on
% selected cells centroids;
% to use this script you need n files containing segmented masks named BW,
% corresponding to n-number of tracked days

% this function is associated with article:  Pectin homogalacturonan nanofilament expansion drives morphogenesis in
% plant epidermal cells, Haas et al., Science 2020. DOI: 10.1126/science.aaz5103

% you test data mask_day1,2,3, to use original jpeg image files fallow the
% link in the article and use WT raw data.

ndaytrack =3;% number of days to track, maximum 5, can be easly daopted for any number of images/days 

file1 = uigetfile('get first day file','*.mat');
load(file1,'BW'); % file1 must contain segmented binary image of cells from day1 with the name BW 
BW1 = BW;
% day 2
file2 = uigetfile('get second day file','.mat');
load(file2,'BW');
BW2 = BW;                    
if ndaytrack >= 3
file3 = uigetfile('get third day file','.mat');

load(file3,'BW');
BW3 = BW;   
end
if ndaytrack >= 4
    file4 = uigetfile('get fourth day file','.mat');
    load(file4,'BW');
    BW4 = BW;   
end
if ndaytrack == 5
    file5 = uigetfile('get fifth day file','.mat');
    load(file5,'BW');
    BW5 = BW;  
end

clear BW 
%% tracking day 4 and 5
if ndaytrack == 5
    uiwait(msgbox({'Select the same cells (min 4) in both images';'Image from day 5 is shown first';...
    'Make sure that selected cells are present in both images';...
    '(dispalayed on the bottom of the screen'},'modal'));

[mark45,mark54,~,L5,y5af,x5af,Dmin54,Imin54,track54,...
~,~,tform5to4,~,~,flag54,lab45,lab54] = autotrackFun(BW4,BW5);
end
% the image with title  Day 2 (5) with day 1 (4) align shows image mask from day
% two with the centroids of the . same tracked cells from day 1 dispalyed
% in magenta.
% Cells which were not trackedd correctly are dispalyed in white
%% tracking day 3 and 4
if ndaytrack >= 4
    uiwait(msgbox({'Select the same cells (min 4) in both images';'Image from day 4 is shown first';...
    'Make sure that selected cells are present in both images';...
    '(dispalayed on the bottom of the screen'},'modal'));

[mark34,mark43,~,L4,y4af,x4af,Dmin43,Imin43,track43,...
~,~,tform4to3,~,~,flag43,lab34,lab43] = autotrackFun(BW3,BW4);
end
% the image with title  Day 2 (4) with day 1 (3) align shows image mask from day
% two with the centroids of the . same tracked cells from day 1 dispalyed
% in magenta.
% Cells which were not trackedd correctly are dispalyed in white
%% tracking day 2 and 3
if ndaytrack >= 3
    uiwait(msgbox({'Select the same cells (min 4) in both images';'Image from day 3 is shown first';...
    'Make sure that selected cells are present in both images';...
    '(dispalayed on the bottom of the screen'},'modal'));

[mark23,mark32,~,L3,y3af,x3af,Dmin32,Imin32,track32,...
~,~,tform3to2,~,~,flag32,lab23,lab32] = autotrackFun(BW2,BW3);
end
% the image with title  Day 2 (3) with day 1 (2) align shows image mask from day
% two with the centroids of the . same tracked cells from day 1 dispalyed
% in magenta.
% Cells which were not trackedd correctly are dispalyed in white
%% tracking day1 and 2
uiwait(msgbox({'Select the same cells (min 4) in both images';'Image from day 2 is shown first';...
    'Make sure that selected cells are present in both images';...
    '(dispalayed on the bottom of the screen'},'modal'));
[mark12,mark21,L1,L2,y2af,x2af,Dmin21,Imin21,track21,...
~,~,tform2to1,~,~,flag21,lab12,lab21] = autotrackFun(BW1,BW2);

% the image with title  Day 2 (2) with day 1 (1) align shows image mask from day
% two with the centroids of the . same tracked cells from day 1 dispalyed
% in magenta.
% Cells which were not trackedd correctly are dispalyed in white
%% tracking
datatracktemp(:,2) = track21(:,2);
datatracktemp(:,1) = NaN;
tmp21 = unique(Imin21,'stable');
for fi = 1:numel(tmp21)
    
    ind = find(Imin21 == tmp21(fi));
    [min21,inmin] = min(Dmin21(ind));
    datatracktemp(ind(inmin),1) = tmp21(fi);

end
%% track  cells from day 2 to day 3
if ndaytrack >= 3
datatracktemp(:,3) = NaN;
% tmp32 = unique(Imin32,'stable');
for fi = 1:numel(datatracktemp(:,1))
    
    val = datatracktemp(fi,2);
    if ~isnan(val)
    ind = find(track32(:,1) == val);
    [min21,inmin] = min(Dmin32(ind));
     if ~isempty(ind)
        datatracktemp(fi,3) = track32(ind(inmin),2);
     end
    end

end  
end
%% track  cells from day 3 to day 4
if ndaytrack >= 4
datatracktemp(:,4) = NaN;
% tmp32 = unique(Imin32,'stable');
for fi = 1:numel(datatracktemp(:,1))
    
    val = datatracktemp(fi,3);
    if ~isnan(val)
    ind = find(track43(:,1) == val);
    [min21,inmin] = min(Dmin43(ind));
     if ~isempty(ind)
        datatracktemp(fi,4) = track43(ind(inmin),2);
     end
    end

end  
end

%% track  cells from day 4 to day 5
if ndaytrack >= 5
datatracktemp(:,5) = NaN;
% tmp32 = unique(Imin32,'stable');
for fi = 1:numel(datatracktemp(:,1))
    
    val = datatracktemp(fi,4);
    if ~isnan(val)
    ind = find(track54(:,1) == val);
    [min21,inmin] = min(Dmin54(ind));
     if ~isempty(ind)
        datatracktemp(fi,5) = track54(ind(inmin),2);
     end
    end

end  
end

%% clear useless data
clear L1relab L2relab L3relab L4relab L5relab min21
clear tmp tmp21 tmp32
clear val struct12 struct21 struct23 struct 32 struct34 struct 43 struct45 struct54

clear struct1 struct2 struct3 struct4 struct5
clear struct32 struct43
clear RGB ind inmin fi ci
clear RGB ind inmin fi ci
clear BBW1 BBW2 BBW3 BBW4 BBW5 b k
%% saveing the data
datatrack = datatracktemp;
datatrack(any(isnan(datatrack),2),:) = [];
C = who;
C(strcmp(C, 'file')) = []; C(strcmp(C, 'Pix_SS')) = [];
C(strcmp(C, 'BW3')) = [];C(strcmp(C, 'savename')) = [];
C(strcmp(C, 'BW2')) = [];
C(strcmp(C, 'BW1')) = [];
C(strcmp(C, 'BW4')) = [];
C(strcmp(C, 'BW5')) = [];
C(strcmp(C, 'C')) = [];
uisave(C,strcat(file1(1:14),'_track_',num2str(ndaytrack),'day','.mat'));
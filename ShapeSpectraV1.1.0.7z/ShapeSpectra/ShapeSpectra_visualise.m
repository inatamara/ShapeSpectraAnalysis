% this script creates different plots to visualize cellular shape spectra
% including: radius, FFT of radious (shape spectra)
% in order to usis you must have generate a shape spectra file with
% ShapeSpectra script. You can use an eample data in the file
% ShapeSpectraSampleData_Curv.mat, select the cell of interest below and just run this script

% this function is associated with article:  Pectin homogalacturonan nanofilament expansion drives morphogenesis in
% plant epidermal cells, Haas et al., Science 2020. DOI: 10.1126/science.aaz5103
% To acknowledge its use, please cite the above article
nday = 3; % number of tracked days
icell = 12; % cellect cell to plot the data for
freqcutoff = 0.2; % frequency cut off for the FT plot display
ymax_rho = 50; % y axis scaling for the rho plot
ymaxRhoFT = 100; % y axis scaling  for the FT of rho
minHinterjunct = 5;
fszl=8; % Fontsize legend
fontname='Helvetica'; % Fontsize name
alw=1.5;% AxesLineWidth
fsz=10; % Fontsize
ms=12; % MarkerSize
fszl=8; % Fontsize legend
Pix_SS = get(0,'screensize');
lw = 2;
promin = 0; % min peak prominence
minH = 10; % min peak height
maxFFT = 1400;
fs = 12;
Ts = 100/463; % pixel size in \mum
Fs = 1/Ts;
close all

%% plot resampled cellular outlines rhoRes
width = Pix_SS(3)/3;
height = Pix_SS(4)/8;
figure
hold on;
for iday = 1:3
    
    x = Ts*(1:numel(rhoRes{icell}(:,iday)))';
    y = rhoRes{icell}(:,iday)-min(rhoRes{icell}(:,iday));
    pl(iday) = plot(x,y,'-','LineWidth',2);

    ylim([0,40])
    % axis square
     title(sprintf('cell %d',icell))
    xl  = xlabel(' RhoRes (\mum)');
    set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')   
    set(gca,'Fontname',fontname,'FontSize',fsz)    
    yl = ylabel(gca, 'Radius (\mum)');
    set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')
    set(gca,'TickDir','out') 
    set(gca,'linewidt',alw) 
    if iday == 3
        % get the cellular junction points
        rhoseg = cell2mat(cellfun(@numel,rhointerj{icell,iday},'UniformOutput',false));
        juncpt(1,1) = x(1);
        juncpt(1,2) = y(1);
        for ji = 1:numel(rhoseg)
            juncpt(ji,1) = x(sum(rhoseg(1:ji)));
            juncpt(ji,2) = y(sum(rhoseg(1:ji)));
        end
        plot(juncpt(:,1),juncpt(:,2),'.k','MarkerSize',15);  
    end
end
set(gcf,'units','pixels','Position',[Pix_SS(1)+2 Pix_SS(2) width height])
legend({'day 1','day 2','day 3'})
savefig(strcat('cell',num2str(icell),'_','rhoRes','.fig'))
%% plot the FT  for rhoRes
figure
hold on;
Ld = (0:npres(icell)-1)/npres(icell);
for iday = 1:nday
Ld = linspace(0, 1, fix(npres(icell))/2+1)*Fs/2; 
Ld = Ld(:);
xfftRes = Ld(1:size(FFTrhoResAbs{icell},1));%floor(npres(icell)/2)-1
% absFFT = FFTrhoResAbs{icell}(:,iday);
absFFT = sqrt(FFTrhoResAbs{icell}(:,iday));
plot(xfftRes,absFFT,'-',...
    'LineWidth',2);

% absFFT = FFTrhoResAbs{icell}(:,iday);
minHeight = minH;
absFFT = sqrt(FFTrhoResAbs{icell}(:,iday));
minHeight = sqrt(minH);
findpeaks(absFFT,xfftRes,'MinPeakHeight',minHeight,'Annotate','extents');
end
% title(sprintf('day:  %d',iday))
xl = xlabel('Frequency (\mum^-^1)');
yl = ylabel('|Y(f)|');
xlim([0,freqcutoff])
% axis square
%  title(sprintf('cell %d, day %d',icell,iday))
% xl  = xlabel('Perimeter localion (\mum)');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')   
set(gca,'Fontname',fontname,'FontSize',fsz)    
% yl = ylabel(gca, 'Radius (\mum)');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')
set(gca,'TickDir','out') 
set(gca,'linewidt',alw) 

set(gcf,'units','pixels','Position',[Pix_SS(1)+2 Pix_SS(2) width height])
legend({'day 1','day 2','day 3'})
% ylim([0,100])
savefig(strcat('cell',num2str(icell),'_','FFTrhoRes','.fig'))
%% rho and FFTrho
col = [131,104,144]/255;
width = Pix_SS(3)/3;
height = Pix_SS(4)/4;
promin = 0;%*Ts; % min peak prominence
minH = 10;%*Ts; % min peak height
for iday = 1:3
    for ipeak = 1:numel(pksIinteg{icell,iday}(:,10))
          labs{ipeak} = num2str(2*round(pksIinteg{icell,iday}(ipeak,10)*10)/10);
    end
x = Ts*(1:numel(rho{icell,iday}))'; % scaling by the pixel size Ts
y = rho{icell,iday}-min(rho{icell,iday});
figure('Visible','On');%figure;
clear juncpt
subplot(2,1,1)
pl = plot(Ts*(1:numel(rho{icell,iday})),(rho{icell,iday}-min(rho{icell,iday})));
set(pl,'LineWidth',lw,'Color',col)
hold on;
rhoseg = cell2mat(cellfun(@numel,rhointerj{icell,iday},'UniformOutput',false));
juncpt(1,1) = x(1);
juncpt(1,2) = y(1);
for ji = 1:numel(rhoseg)
    juncpt(ji,1) = x(sum(rhoseg(1:ji)));
    juncpt(ji,2) = y(sum(rhoseg(1:ji)));
end
plot(juncpt(:,1),juncpt(:,2),'.k','MarkerSize',15);
xl  = xlabel('Perimeter localion (\mum)');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')   
set(gca,'Fontname',fontname,'FontSize',fsz)    
yl = ylabel(gca, 'Radius (\mum)');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')
set(gca,'TickDir','out') 
set(gca,'linewidt',alw) 
ylim([0,ymax_rho])
box off
subplot(2,1,2)
Ld = (0:np(icell,iday)-1)*Fs/np(icell,iday);
Ld = Ld(:);
xfft = Ld(1:numel(FFTrho{icell,iday}));%floor(np(icell,iday)/2)-1
pl1 = plot(xfft,sqrt(FFTrhoAbs{icell,iday}));
hold on;
set(pl1,'LineWidth',lw,'Color',col)

findpeaks(sqrt(FFTrhoAbs{icell,iday}),xfft,'MinPeakHeight',...
sqrt(minH),'Annotate','extents');

ylim([0,ymaxRhoFT])
xlim([0,freqcutoff])
xl  = xlabel('Normalized frequency');
set(gca,'Fontname',fontname, 'Fontsize', fsz) 
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k') 
yl = ylabel(gca, '|FFT(Radius)|');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k') 
%         title(sprintf('cell %d, day %d',icell,iday))
xticks(nonzeros(pksIinteg{icell,iday}(:,2)))
xticklabels(labs(pksIinteg{icell,iday}(:,2) ~=0))
legend off
box off
set(gca,'TickDir','out') 
set(gca,'linewidt',alw) 
clear labs
   set(gcf,'units','pixels','Position',[Pix_SS(1)+2 Pix_SS(2) width height])  
   savefig(strcat('cell',num2str(icell),'_','day_',num2str(iday),'rhoANDFFTrho','.fig'))
end
%% ploting the interjunctional segments
n1 = numel(internodeD{icell,1});
n2 = numel(internodeD{icell,2});
n3 = numel(internodeD{icell,3});

njunc = min([n1,n2,n3]);
figure;

for iday = 1:nday 
% figure;
bound = cell2mat(internodeSEG{icell,iday}');
subplot(1,4,iday)
hold on  
leg{icell,iday} = '';
    for ijunc = 1:njunc
       tmp = internodeSEG{icell,iday}{1,ijunc};
       tmp(:,1) = tmp(:,1) - min(bound(:,1));
       tmp(:,2) = tmp(:,2) - min(bound(:,2));
       x = [1:numel(tmp(:,1))]/numel(tmp(:,1));
       plot(x,detrend(tmp(:,2)),'.-');
%          plot(tmp(:,1),tmp(:,2),'.-');
       leg{icell,iday}{ijunc,1} = num2str(round(numel(x)*Ts));
       junclength{icell}(ijunc,iday) = numel(x)*Ts;
    end  
    l = legend(leg{icell,iday});
    set(l,'Fontname',fontname,'FontSize',fszl)
    tl = title(sprintf('Day: %d',iday));
    set(gca,'Fontname',fontname,'FontSize',fsz) 
    set(gca,'TickDir','out') 
    set(gca,'linewidt',alw) 
    set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')   
%     axis tight
    axis square
end
subplot(1,4,4)
plot([junclength{icell}./junclength{icell}(:,1)]','LineWidth',lw)
set(gca,'Fontname',fontname,'FontSize',fsz) 
set(gca,'TickDir','out') 
set(gca,'linewidt',alw) 
set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')   
%     axis tight
axis square
xticklabels({'day 1','day 2','day 3'});

set(gcf,'units','pixels','Position',[Pix_SS(1)+2 Pix_SS(2) width height])
savefig(strcat('cell',num2str(icell),'_','interjunc.fig'))
%%
n1 = numel(internodeD{icell,1});
n2 = numel(internodeD{icell,2});
n3 = numel(internodeD{icell,3});

njunc = min([n1,n2,n3]);
figure;

for iday = 1:nday 
% figure;
bound = cell2mat(internodeSEG{icell,iday}');
subplot(1,3,iday)

    for ijunc = 1:njunc
%        tmp = internodeSEG{icell,iday}{1,ijunc};
%          plot(tmp(:,1),tmp(:,2),'.-');
        theta = deg2rad(angleSqinterj{icell,iday}{ijunc,1});
        rad = rhointerj{icell,iday}{ijunc,1};
        polarplot(theta,rad,'LineWidth',3)
        hold on;
        Ax = gca; % current axes
        Ax.RTickLabel = []; 
        Ax.ThetaTickLabel = [];
         
    end  
    tl = title(sprintf('Day: %d',iday));
    set(gca,'Fontname',fontname,'FontSize',fsz) 
    set(gca,'TickDir','out') 
    set(gca,'linewidt',alw) 
    set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')   

end
set(gcf,'units','pixels','Position',[Pix_SS(1)+2 Pix_SS(2) width height])
%%  plot rhoRes and FT rhoRes

for ii = 1:nday
    for ipeak = 1:numel(pksIintegRes{icell,ii}(:,10))
          labs{ipeak} = num2str(2*round(pksIintegRes{icell,ii}(ipeak,10)*10)/10);
    end
figure('Visible','On');%figure;
subplot(2,1,1)
pl = plot(Ts*(1:numel(rhoRes{icell}(:,ii))),1*(rhoRes{icell}(:,ii)-min(rhoRes{icell}(:,ii))));
set(pl,'LineWidth',lw,'Color',col)
xl  = xlabel('Perimeter localion (\mum)');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')   
set(gca,'Fontname',fontname,'FontSize',fsz)    
yl = ylabel(gca, 'Radius(\mum)');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k') 
set(gca,'TickDir','out') 
set(gca,'linewidth',alw) 
box off
if ii == 3
    hold on;
rhoseg = cell2mat(cellfun(@numel,rhointerj{icell,ii},'UniformOutput',false));
x = Ts*(1:numel(rhoRes{icell}(:,iday)))';
y = rhoRes{icell}(:,iday)-min(rhoRes{icell}(:,iday));
juncpt(1,1) = x(1);
juncpt(1,2) = y(1);
for ji = 1:numel(rhoseg)
    juncpt(ji,1) = x(sum(rhoseg(1:ji)));
    juncpt(ji,2) = y(sum(rhoseg(1:ji)));
end
plot(juncpt(:,1),juncpt(:,2),'.k','MarkerSize',15);
end
ylim([0,40])
%     title(sprintf('cell %d, day %d',icell,ii))
subplot(2,1,2)
Ld = (0:npres(icell)-1)*Fs/npres(icell);
Ld = Ld(:);
xfftRes = Ld(1:size(FFTrhoResAbs{icell},1));%floor(npres(icell)/2)-1
pl1 = plot(xfftRes,sqrt(FFTrhoResAbs{icell}(:,ii)));
hold on;
set(pl1,'LineWidth',lw,'Color',col)

findpeaks(sqrt(FFTrhoResAbs{icell}(:,ii)),xfftRes,...
'MinPeakHeight',sqrt(minH),'Annotate','extents');
ylim([0,100])
xlim([0,0.17])

set(gca,'Fontname',fontname, 'Fontsize', fszl) 
xl  = xlabel('Normalized frequency');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k') 
yl = ylabel(gca, '|FFT(Radius)|');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k') 
%     title(sprintf('cell %d, day %d',icell,ii))
xticks(pksIintegRes{icell,ii}(:,2))
xticklabels(labs)
legend off
clear labs
set(gca,'TickDir','out') 
set(gca,'linewidt',alw) 
box off
set(gcf,'units','pixels','Position',[Pix_SS(1)+2 Pix_SS(2) width height])    
savefig(strcat('cell',num2str(icell),'_','day_',num2str(ii),'rhoANDFFTrhoRes','.fig'))
end
%% polar plot of the cellular segments
numhar = 4; % number fo harmonics to be ploted
width = Pix_SS(3)/4;
height = Pix_SS(4)/6;

for har = 1:numhar

res = 0;
cmap = jet(2);
num = 20;
figure;
clear juncpt
for iday = 1:nday
  
theta = deg2rad(angleSq{icell,iday});

harmonic = round(pksIinteg{icell,iday}(:,6)*10)/10;
rad = rho{icell,iday};
seg = ceil(pksIinteg{icell,iday}(har,9)./...
harmonic(har));%pksIinteg{icell,iday}(har,6));
rhoseg = cell2mat(cellfun(@numel,rhointerj{icell,iday},'UniformOutput',false));
juncpt(1,1,iday) = rad(1);
juncpt(1,2,iday) = theta(1);
for ji = 1:numel(rhoseg)
juncpt(ji,1,iday) = rad(sum(rhoseg(1:ji)));
juncpt(ji,2,iday) = theta(sum(rhoseg(1:ji)));
sum(rhoseg(1:ji))
end

[M,I] = min(rad);
nel = numel(rad)+1;
radsort = circshift(rad,nel-I);
radsort = rad;
thetasort = circshift(theta,nel-I);
thetasort = theta;
thetasort = [thetasort;thetasort];
radsort = [radsort;radsort];

for ii = 1:harmonic(har)
subplot(1,3,iday)
pl = polarplot(thetasort(1+(ii-1)*seg:1+ii*seg-1),...
radsort(1+(ii-1)*seg:1+ii*seg-1),'LineWidth',3); %,'Color',cmap(ii,:)
hold on;
polarplot(juncpt(:,2,iday),juncpt(:,1,iday),'.k','MarkerSize',15)

Ax = gca; % current axes
Ax.RTickLabel = []; 
Ax.ThetaTickLabel = [];
end

tl = title(sprintf('# of cycles: %d',harmonic(har)));
set(gca,'Fontname',fontname,'FontSize',fsz) 
set(gca,'TickDir','out') 
set(gca,'linewidt',alw) 

rtick = [0,round(max(radsort))];
set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')   
set(gcf,'units','pixels','Position',[Pix_SS(1)+2 Pix_SS(2) width height])
savefig(strcat('cell',num2str(icell),'_','harmonic',num2str(har),'.fig'))
end
end
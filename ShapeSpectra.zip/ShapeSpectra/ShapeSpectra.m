% this function is associated with article: 'Nanoscopy reveals pectin
% filaments and their role in plant epidermal morphogenesis' currently
% under review
% This file performs cell shape spectra analysis.
% It performs Fourier Transform (FT) on the cellular outlines, resampled
% cellular outlines and interjunctional segments (outline segments between tricellular junction)
% use the TRACK5 files after junction correction and junction tracking with
% ShapeSpectra_CellJunctionFinalAssembly and other functions
% For the test, use ShapeSpectra_SampleData_TRACK5.mat file
clear all;
close all;
clc
if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end

Ts = 100/463; % pixel size in um
Fs = 1/Ts;
%%
searchflag = '_TRACK5';
files = dir(pwd);
fnames = {files.name}'; 
tfmat = ~cellfun('isempty',strfind(fnames,'.mat'));
fnames = fnames(tfmat);
tfmat = ~cellfun('isempty',strfind(fnames,searchflag));%locates the files with _track5 in the name
% track5 file contains tracked and corrected masks
fnamesTR1 = fnames(tfmat);
numfile = numel(fnamesTR1);
%%
peak1 = [];
ovt1 = [];
pksnum1 =  [];
areaBatch1 =  [];
plotrhores = 0;
plotrho = 0;
pptx=0;
imsize = 3000;%max(npres);
FInpinterjunc = [];
cellcount = 0;
nday = 3;% numbner of tracked days
for nfi = 1:numfile

filenametrack = fnamesTR1{nfi};
load(filenametrack);
name = strcat(filenametrack(1:end-10),'_fft');
ncells = size(internodeD,1);
% if ~exist(filetosave,'file')
clc
step = [2,3,4];
windowWidth = 7; % Golay filter window for the cellular contour
polynomialOrder = 2; % polynomial oredr for golay filterGolay filter
promin = 0;% min peak prominence in FT
minH = 10;% % min peak height in FT
recur = fliplr([8,8,8]);
rho = cell(ncells,nday);
angleSq = cell(ncells,nday);
nday = 3;
minHinterjunct = 5;
% initialising variables
SE = strel('square', 5);
x = cell(ncells,nday);
y = cell(ncells,nday);
sX = cell(ncells,nday);
sY = cell(ncells,nday);
x1 = cell(ncells,nday);
y1 = cell(ncells,nday);
Par = cell(ncells,nday);
bSq = cell(ncells,nday);
np = zeros(ncells,nday);

Dil = cell(ncells,nday);
IMcrop = cell(ncells,nday); % cropped images of each cell at each day
pix = 1; %pixel size in microns
cellarea = zeros(ncells,nday);
X0 = zeros(ncells,nday);
Y0 = zeros(ncells,nday);
Branchcrop  = cell(ncells,nday);
boundaries = cell(ncells,nday);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialization of variables related to cellular outlines rho
FFTrhoAbs  = cell(ncells,nday); % absolute value of Fourier transform of cellular outlines rho
FFTrho = cell(ncells,nday); % Fourier transform of cellular outlines rho
pks = cell(ncells,nday);% cell array containing amplitude of peaks 
%in FT, for each cell, n cell and each day, nday
locs = cell(ncells,nday);% cell array containing absolute frequency of peak
%in FT, for each cell, n cell and each day, nday
pksw = cell(ncells,nday);% cell array containing peaks' widths
%in FT, for each cell, n cell and each day, nday
pksprom = cell(ncells,nday);% cell array containing peaks' prominence
%in FT, for each cell, n cell and each day, nday
peakInterval = cell(ncells,nday); % frequency intervals between sussesive peaks in FT
peakHInterval = cell(ncells,nday);
pksIinteg = cell(ncells,nday);
% pksIinteg contains the result of the peak analysis in the Fourier
% transform of cellular outlines rho
% pksIinteg is a cell array, where rows correspond to individual tracked cells and columns
% to days. Each cell array  entry is a matrix, which
% rows correspond to succesive peaks in Fourier transform and
% colums correspond to the following variables:
% 1 - intergrated energy 
% 2 - absolute frequency (frequency at the maximum of the peak)
% 3 - peak amplitude
% 4 - peak width
% 5 - peak prominence
% 6 - peak normalised frequency
% 7 peak wavelength (inverse of the absolute frequency
% 8 - cell area
% 9 length of the rho

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialization of variables related to resampled cellular outlines rho
rhoRes = cell(ncells,1); % resampled cellular outlines for all cells (rows of the cell array)
% at three succesive days (columns each cell array entry)
FFTrhoRes = cell(ncells,1); % Fourier transform of rhoRes
FFTrhoResAbs = cell(ncells,1);% absolute value of Fourier transform of resampled cellular outlines rho
% cellular outlines are resampled relative to the last day, the longest
% data, so that at each data thoRes has the same number of points

% analysis of fourier spectra
pksRes = cell(ncells,nday);% cell array containing amplitude of peaks 
%in FT, for each cell, n cell and each day, nday
locsRes = cell(ncells,nday); % cell array containing absolute frequency of peak
%in FT, for each cell, n cell and each day, nday
pkswRes = cell(ncells,nday);% cell array containing peaks' widths
%in FT, for each cell, n cell and each day, nday
pkspromRes = cell(ncells,nday);% cell array containing peaks' prominence
%in FT, for each cell, n cell and each day, nday
peakIntervalRes = cell(ncells,nday);
peakHIntervalRes = cell(ncells,nday);
xfftRes = cell(ncells,1);
npres = zeros(ncells,1);
pksIintegRes = cell(ncells,nday);
% pksIintegRes contains the result of the peak analysis in the Fourier
% transform of the resampled cellular outlines rhoRes
% pksIintegRes is a cell array, where rows correspond to individual tracked cells and columns
% to days. Each cell array  entry is a matrix, which
% rows correspond to succesive peaks in Fourier transform and
% colums correspond to the following variables:
% 1 - intergrated energy 
% 2 - absolute frequency (frequency at the maximum of the peak)
% 3 - peak amplitude
% 4 - peak width
% 5 - peak prominence
% 6 - peak normalised frequency
% 7 peak wavelength (inverse of the absolute frequency
% 8 - cell area
% 9 length of the rho

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialization of variables related to  segments of cellular outlines rhointerj
rhointerj = cell(ncells,nday); % interjunctional cellular segments
angleSqinterj = cell(ncells,nday); % corresponding angles for rhointerj (in polar coordinates)
FFTrhointerj = cell(ncells,nday); % FT on interjunctional cellular segments
FFTrhointerjAbs = cell(ncells,nday); % absolute value of FT
pksinterjunc = cell(ncells,nday);
% pksinterjunc contains Fourier analysis on the cellular interjunction
% segmlents rhoj
% pksinterjunc is a cell array of cell array, where rows and columns correspond to track
% cellsa and day respectivelly, each entry is a cell arrays with the number
% of cells equals to the number of cell junctions
locsinterjunc = cell(ncells,nday);
pksinterjuncw = cell(ncells,nday);
pksinterjuncprom = cell(ncells,nday);
pksinterjuncIinteg = cell(ncells,nday);
numNN = zeros(ncells,nday);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for icell = 1:ncells
    
    cellcount = cellcount + 1;
    
    clear skel
for iday = 1:nday
    rho{icell,iday} = [];
    angleSq{icell,iday} = [];
    numNN(icell,iday) = numel(internodeD{icell,iday});
    clear tmp L tmp1 struct tmp1 branchloc skel conhull
    L = eval(strcat('L',num2str(iday)));
    BW = eval(strcat('BW',num2str(iday)));
    skel = eval(strcat('skel',num2str(iday)));
    % find all branchponts in skeleton for all cells
    branchloc = eval(strcat('newbranch',num2str(iday)));
    cen = eval(strcat('cen',num2str(iday)));
    tmp = L == icell+10;
    boundfull = bwboundaries(tmp, 'noholes');
    if isempty(boundfull)
        continue;
    else
    boundaries{icell,iday} = [boundfull{1}(:,2),boundfull{1}(:,1)];
    struct  = regionprops(tmp,'BoundingBox', 'Centroid');
%  if ~isempty(internodeSEG{icell,iday}  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % analysis of interjunction segments
    % converting to radious in circular coordiante
    for ijunc = 1:numel(internodeSEG{icell,iday})
    [rhointerj{icell,iday}{ijunc,1}, angleSqinterj{icell,iday}{ijunc,1}] = ...
    signatureB(Ts*[internodeSEG{icell,iday}{1,ijunc}(:,2),...
    internodeSEG{icell,iday}{1,ijunc}(:,1)],...
    Ts*cen{1,icell}(:,2),Ts*cen{1,icell}(:,1));
    npinterjunc(icell,iday,ijunc) = numel(rhointerj{icell,iday}{ijunc,1});
    pksinterjuncIinteg{icell,iday}{ijunc,1} = zeros(1,10);
    pksinterjuncIinteg{icell,iday}{ijunc,1}(1,9) = npinterjunc(icell,iday,ijunc);
   rho{icell,iday} = [rho{icell,iday};rhointerj{icell,iday}{ijunc,1}];
   angleSq{icell,iday}  = [angleSq{icell,iday};angleSqinterj{icell,iday}{ijunc,1}];
        % fourier analysis on interjunction segments
    XFFT = detrend(rhointerj{icell,iday}{ijunc,1})-min(detrend(rhointerj{icell,iday}{ijunc,1}));
%     XFFT = XFFT .* hann(numel(XFFT));
    tmpfft = fft(XFFT,npinterjunc(icell,iday,ijunc));%/sqrt(np(icell,iday));
    FFTrhointerj{icell,iday}{ijunc,1} = tmpfft(1:floor(npinterjunc(icell,iday,ijunc)/2));
    FFTrhointerjAbs{icell,iday}{ijunc,1} = abs(Ts*FFTrhointerj{icell,iday}{ijunc,1}(1:end));
    FFTrhointerjAbs{icell,iday}{ijunc,1}(2:end) = FFTrhointerjAbs{icell,iday}{ijunc,1}(2:end)*2;
     Ld = (0:npinterjunc(icell,iday,ijunc)-1)*Fs/npinterjunc(icell,iday,ijunc);
     Ld = Ld(:);
    xfft = Ld(1:numel(FFTrhointerj{icell,iday}{ijunc,1}));
    try % if there is noo peak in the interjunction FT, this chunk is skipped
    [pksinterjunc{icell,iday}{ijunc,1}, locsinterjunc{icell,iday}{ijunc,1},...
        pksinterjuncw{icell,iday}{ijunc,1}, pksinterjuncprom{icell,iday}{ijunc,1}] = ...
    findpeaks((FFTrhointerjAbs{icell,iday}{ijunc,1}),xfft,'MinPeakHeight',minHinterjunct);
    peakInterval{icell,iday}{ijunc,1} = diff(locsinterjunc{icell,iday}{ijunc,1}); 
    peakHInterval{icell,iday}{ijunc,1} = -1*diff(pksinterjunc{icell,iday}{ijunc,1});
    absFFT = FFTrhointerjAbs{icell,iday}{ijunc,1}.^2;
    df = Fs/(npinterjunc(icell,iday,ijunc))/2;
    for ipeak = 1:numel(pksinterjunc{icell,iday}{ijunc,1})
        
        enes = locsinterjunc{icell,iday}{ijunc,1}(ipeak) + pksinterjuncw{icell,iday}{ijunc,1}(ipeak);
        stes = locsinterjunc{icell,iday}{ijunc,1}(ipeak) - pksinterjuncw{icell,iday}{ijunc,1}(ipeak);
        peakloci = locsinterjunc{icell,iday}{ijunc,1}(ipeak);
        [val,inden] = min(abs(xfft - enes));
        en = xfft(inden(1));
        [val,indst] = min(abs(xfft - stes));
        st = xfft(indst(1));
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,1) = trapz(xfft(indst:inden),df*absFFT(indst:inden));
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,2) = locsinterjunc{icell,iday}{ijunc,1}(ipeak);
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,3) = pksinterjunc{icell,iday}{ijunc,1}(ipeak);
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,4) = pksinterjuncw{icell,iday}{ijunc,1}(ipeak);
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,5) = pksinterjuncprom{icell,iday}{ijunc,1}(ipeak);
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,6) = locsinterjunc{icell,iday}{ijunc,1}(ipeak)*npinterjunc(icell,iday,ijunc)*Ts;
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,7) = 1./locsinterjunc{icell,iday}{ijunc,1}(ipeak);
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,8) = cellarea(icell,iday);
        pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,9) = npinterjunc(icell,iday,ijunc);
        if ipeak > 1
            if pksinterjuncIinteg{icell,iday}{ijunc,1}(1,6) == 2
                pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,10) = locsinterjunc{icell,iday}{ijunc,1}(ipeak)/locsinterjunc{icell,iday}{ijunc,1}(1);
            elseif pksinterjuncIinteg{icell,iday}{ijunc,1}(1,6) == 4
                 pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,10) = locsinterjunc{icell,iday}{ijunc,1}(ipeak)/locsinterjunc{icell,iday}{ijunc,1}(1)/2;
            elseif pksinterjuncIinteg{icell,iday}{ijunc,1}(1,6) == 6
                 pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,10) = locsinterjunc{icell,iday}{ijunc,1}(ipeak)/locsinterjunc{icell,iday}{ijunc,1}(1)/3;  
            elseif pksinterjuncIinteg{icell,iday}{ijunc,1}(1,6) == 8
                 pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,10) = locsinterjunc{icell,iday}{ijunc,1}(ipeak)/locsinterjunc{icell,iday}{ijunc,1}(1)/4;   
            else
                 pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,10) = locsinterjunc{icell,iday}{ijunc,1}(ipeak)/locsinterjunc{icell,iday}{ijunc,1}(1);
            end
        else
            pksinterjuncIinteg{icell,iday}{ijunc,1}(ipeak,10) = 1;
            
        end
       
    end
    % end of fourier on the interjunc
    catch
%         pksinterjuncIinteg{icell,iday}{ijunc,1} = zeros(1,10);
%         pksinterjuncIinteg{icell,iday}{ijunc,1}(1,9) = npinterjunc(icell,iday,ijunc);
    end
    end
    end
        

    IMcrop{icell,iday} = imcrop(tmp, struct.BoundingBox);
    struct  = regionprops(IMcrop{icell,iday}, 'Centroid','Area');
    cellarea(icell,iday) = cat(1, struct.Area);
    centroids = cat(1, struct.Centroid);
    X0(icell,iday) = centroids(:,1);
    Y0(icell,iday) = centroids(:,2);
    bound = bwboundaries(IMcrop{icell,iday}, 'noholes');
    bSq{icell,iday} = bound{1};
    x{icell,iday} = bSq{icell,iday}(:, 2);
    y{icell,iday} = bSq{icell,iday}(:, 1);
   
    if windowWidth
        sX{icell,iday} = sgolayfilt(x{icell,iday}, polynomialOrder, windowWidth);
        sY{icell,iday} = sgolayfilt(y{icell,iday}, polynomialOrder, windowWidth);
    else
        sX{icell,iday} = x{icell,iday};
        sY{icell,iday} = y{icell,iday};
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fourier analysis of cellular outlines  rho
    np(icell,iday) = numel(rho{icell,iday});%length(sX{icell,iday});
%fft of rho
    tmpfft = fft((rho{icell,iday}-min(rho{icell,iday})),...
    np(icell,iday));%/sqrt(np(icell,iday));
    FFTrho{icell,iday} = tmpfft(1:floor(np(icell,iday)/2));
    FFTrhoAbs{icell,iday} = abs(Ts*FFTrho{icell,iday}(1:end));%floor(np(icell,iday)/2)-1
    FFTrhoAbs{icell,iday}(2:end) = FFTrhoAbs{icell,iday}(2:end)*2;
     Ld = (0:np(icell,iday)-1)*Fs/np(icell,iday);
     Ld = Ld(:);
    xfft = Ld(1:numel(FFTrho{icell,iday}));%floor(np(icell,iday)/2)-1
    [pks{icell,iday}, locs{icell,iday},pksw{icell,iday}, pksprom{icell,iday}] = ...
    findpeaks((FFTrhoAbs{icell,iday}),xfft,'MinPeakProminence',promin,'MinPeakHeight',minH);
    peakInterval{icell,iday} = diff(locs{icell,iday}); %distance betwen peaks in freq space
    peakHInterval{icell,iday} = -1*diff(pks{icell,iday});
    absFFT = FFTrhoAbs{icell,iday}.^2;
    df = Fs/(np(icell,iday))/2;
    for ipeak = 1:numel(pks{icell,iday})
        try
        enes = locs{icell,iday}(ipeak) + pksw{icell,iday}(ipeak)/2;
        stes = locs{icell,iday}(ipeak) - pksw{icell,iday}(ipeak)/2;
        peakloci = locs{icell,iday}(ipeak);
        [val,inden] = min(abs(xfft - enes));
        en = xfft(inden(1));
        [val,indst] = min(abs(xfft - stes));
        st = xfft(indst(1));
        pksIinteg{icell,iday}(ipeak,1) = trapz(xfft(indst:inden),df*absFFT(indst:inden));
        pksIinteg{icell,iday}(ipeak,2) = locs{icell,iday}(ipeak);
        pksIinteg{icell,iday}(ipeak,3) = pks{icell,iday}(ipeak);
        pksIinteg{icell,iday}(ipeak,4) = pksw{icell,iday}(ipeak);
        pksIinteg{icell,iday}(ipeak,5) = pksprom{icell,iday}(ipeak);
        pksIinteg{icell,iday}(ipeak,6) = locs{icell,iday}(ipeak)*np(icell,iday)*Ts;
        pksIinteg{icell,iday}(ipeak,7) = 1./locs{icell,iday}(ipeak);
        pksIinteg{icell,iday}(ipeak,8) = cellarea(icell,iday);
        pksIinteg{icell,iday}(ipeak,9) = np(icell,iday);
        if ipeak > 1
            if pksIinteg{icell,iday}(1,6) == 2
                pksIinteg{icell,iday}(ipeak,10) = locs{icell,iday}(ipeak)/locs{icell,iday}(1);
            elseif pksIinteg{icell,iday}(1,6) == 4
                 pksIinteg{icell,iday}(ipeak,10) = locs{icell,iday}(ipeak)/locs{icell,iday}(1)/2;
            elseif pksIinteg{icell,iday}(1,6) == 6
                 pksIinteg{icell,iday}(ipeak,10) = locs{icell,iday}(ipeak)/locs{icell,iday}(1)/3;  
            elseif pksIinteg{icell,iday}(1,6) == 8
                 pksIinteg{icell,iday}(ipeak,10) = locs{icell,iday}(ipeak)/locs{icell,iday}(1)/4;   
            else
                 pksIinteg{icell,iday}(ipeak,10) = locs{icell,iday}(ipeak)/locs{icell,iday}(1);
            end
        else
            pksIinteg{icell,iday}(ipeak,10) = 1;
        end
        labs{ipeak} = num2str(round(pksIinteg{icell,iday}(ipeak,10)*10)/10);
        catch
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fourier analysis on resampled rho 
% resampled radious for cell icell and all 3 days
rhoRes{icell} = rhoResample({rho{icell,:}});
% FFT for resampled rho
npres(icell) = size(rhoRes{icell},1);
tmpfft = fft((rhoRes{icell}-min(rhoRes{icell})),...
npres(icell));%/sqrt(npres(icell));
FFTrhoRes{icell}  = tmpfft(1:floor(npres(icell)/2)-1,:);
FFTrhoResAbs{icell} = abs(Ts*FFTrhoRes{icell}(1:end,:));%floor(npres(icell)/2)-1
FFTrhoResAbs{icell}(2:end,:) = FFTrhoResAbs{icell,:}(2:end,:)*2;
% Ld = (0:npres(icell)-1)/(npres(icell));
% Ld = linspace(0, 1, fix(npres(icell))/2+1)*Fs/2; 
Ld = (0:npres(icell)-1)*Fs/npres(icell);
Ld = Ld(:);
xfftRes{icell} = Ld(1:size(FFTrhoResAbs{icell},1));%floor(npres(icell)/2)-1
for ii = 1:nday
    try
    [pksRes{icell,ii}, locsRes{icell,ii},pkswRes{icell,ii}, pkspromRes{icell,ii}] = ...
    findpeaks(FFTrhoResAbs{icell}(:,ii),xfftRes{icell},'MinPeakProminence',promin,'MinPeakHeight',minH);
    peakIntervalRes{icell,ii} = diff(locsRes{icell,ii});
    peakHIntervalRes{icell,ii} = -1*diff(pksRes{icell,ii});
    catch
        pksRes{icell,ii} = [];
        locsRes{icell,ii} = [];
        pkswRes{icell,ii} = [];
        pkspromRes{icell,ii} = [];
    end
    absFFT = FFTrhoResAbs{icell}(:,ii).^2;
    df = Fs/(npres(icell))/2;
    for ipeak = 1:numel(pksRes{icell,ii})
     
    
        enes = locsRes{icell,ii}(ipeak) + pkswRes{icell,ii}(ipeak);
        stes = locsRes{icell,ii}(ipeak) - pkswRes{icell,ii}(ipeak);
        peakloci = locsRes{icell,ii}(ipeak);
        [val,inden] = min(abs(xfftRes{icell} - enes));
        en = xfftRes{icell}(inden(1));
        [val,indst] = min(abs(xfftRes{icell} - stes));
        st = xfftRes{icell}(indst(1));
        pksIintegRes{icell,ii}(ipeak,1) = trapz(xfftRes{icell}(indst:inden),df*absFFT(indst:inden));
        pksIintegRes{icell,ii}(ipeak,2) = locsRes{icell,ii}(ipeak);
        pksIintegRes{icell,ii}(ipeak,3) = pksRes{icell,ii}(ipeak);
        pksIintegRes{icell,ii}(ipeak,4) = pkswRes{icell,ii}(ipeak);
        pksIintegRes{icell,ii}(ipeak,5) = pkspromRes{icell,ii}(ipeak);
        pksIintegRes{icell,ii}(ipeak,6) = locsRes{icell,ii}(ipeak)*npres(icell)*Ts;
        pksIintegRes{icell,ii}(ipeak,7) = 1./locsRes{icell,ii}(ipeak);
        pksIintegRes{icell,ii}(ipeak,8) = cellarea(icell,ii);
        pksIintegRes{icell,ii}(ipeak,9) = npres(icell);

        if ipeak > 1
            if pksIintegRes{icell,ii}(1,6) == 2
                pksIintegRes{icell,ii}(ipeak,10) = locsRes{icell,ii}(ipeak)/locsRes{icell,ii}(1);
                
            elseif pksIintegRes{icell,ii}(1,6) == 4
                 pksIintegRes{icell,ii}(ipeak,10) = locsRes{icell,ii}(ipeak)/locsRes{icell,ii}(1)/2;
                 
            elseif pksIintegRes{icell,ii}(1,6) == 6
                 pksIintegRes{icell,ii}(ipeak,10) = locsRes{icell,ii}(ipeak)/locsRes{icell,ii}(1)/3;  
                 
            elseif pksIintegRes{icell,ii}(1,6) == 8
                 pksIintegRes{icell,ii}(ipeak,10) = locsRes{icell,ii}(ipeak)/locsRes{icell,ii}(1)/4;   
            else
                 pksIintegRes{icell,ii}(ipeak,10) = locsRes{icell,ii}(ipeak)/locsRes{icell,ii}(1);
            end
        else
            pksIintegRes{icell,ii}(ipeak,10) = 1;
        end

        labs{ipeak} = num2str(round(pksIintegRes{icell,ii}(ipeak,10)*10)/10);
    end
   
end
end

%%
filetosave = strcat(filenametrack(1:end-10),'_CURV.mat');
%%
save(filetosave,'rho','rhoRes','angleSq','y','x','IMcrop',...
'sX','sY','step','bSq','windowWidth','polynomialOrder',...
'BW1','BW2','BW3','x1','y1','FFTrho','FFTrhoRes','FFTrhoAbs','pix','np','recur','Par',...
'filenametrack','datatracksort','datatrack',...
'Isort','datameasure','dataout','dataoutnorm','ncells','npres',...
'file1','file2','file3','X0','Y0','dataoutnormSORT','dataoutSORT','L1','L2',...
'L3','s1','s2','s3','pks','pksw','locs','pksprom','peakInterval','peakHInterval',...
'pksRes','pkswRes','locsRes','pkspromRes','peakIntervalRes','peakHIntervalRes',...
'FFTrhoResAbs','minH','pksIintegRes','pksIinteg','cellarea',...
'promin','minH','Fs','Ts','numNN','Branchcrop',...
'boundaries','npinterjunc','internodeSEG','internodeD',...
'rhointerj','angleSqinterj','FFTrhointerjAbs','FFTrhointerj','pksinterjunc',...
'locsinterjunc','pksinterjuncw','pksinterjuncprom','pksinterjuncIinteg','-v7.3') 

%%
disp(strcat('Saved:  ',filetosave));
nfi
FInpinterjunc = [FInpinterjunc;npinterjunc];
FIrhointerj{nfi,1} = rhointerj;
FIpksinterjuncIinteg{nfi,1} = pksinterjuncIinteg;
FIinternodeSEG{nfi,1} = internodeSEG;
FIinternodeD{nfi,1} = internodeD;
FFTdatBatchRes{nfi,1} = pksIintegRes;
FFTdatBatch{nfi,1} = pksIinteg;
radRes{nfi,1} = rhoRes;
rad{nfi,1} = rho;
angleS{nfi,1} = angleSq;
nNN{nfi,1} = numNN;
end
%%
filetosavefi = 'TrackSummary';
save(filetosavefi,'FFTdatBatch','FFTdatBatchRes','rad','radRes','angleS',...
'nNN','FIrhointerj','FIpksinterjuncIinteg',...
'FIinternodeSEG','FIinternodeD','FFTdatBatchRes','FFTdatBatch','FInpinterjunc','-v7.3') 

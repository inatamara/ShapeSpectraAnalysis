function [mark1,mark2,L1,L2,y2af,x2af,Dmin,Imin,track12,...
L1relab,L2relab,tform2to1,struct1,struct2,flag,lab1,lab2] = autotrackFun(BBW1,BBW2)
% This is subfunction called by ShapeSpectraTrackCells.m
%   it will dispalay two images on the bottom of the screen corresponding 
%to two days between which cells are to be tracked 
%  First, the image corresponding to last day (of two) will be displayed
%  and user has to select at least 4 cells by clicking on them with mouse.
%  To select last cell, double click; also look on Matlab impixel webpage
%  for more information

% this function is associated with article: 'Nanoscopy reveals pectin
% filaments and their role in plant epidermal morphogenesis' currently
% under review

Pix_SS = get(0,'screensize');
width = Pix_SS(3)/3;
height = Pix_SS(4)/2;
% adjust image size if different
if numel(BBW2) > numel(BBW1)
    BBW2res = imresize(~imdilate(~BBW2,strel('square',3)),size(BBW1));
    skel = bwmorph(~BBW2res,'skel',Inf);
    skel = debranching(skel, 10,1);
    BBW2 = ~skel; % skeletonize
    flag = 2;

elseif  numel(BBW2) < numel(BBW1)
    BBW1res = imresize(~imdilate(~BBW1,strel('square',3)),size(BBW2));
    skel = bwmorph(~BBW1res,'skel',Inf);
    skel = debranching(skel, 10,1);
    BBW1 = ~skel; % skeletonize
     flag = 1;
else
     flag = 0;
end
%
BW1 = BBW1;
L1 = bwlabel(BW1,4);
RGB1 = label2rgb(L1,'jet',[1 1 1], 'shuffle');
%
BW2 = BBW2;
L2 = bwlabel(BBW2,4);
RGB2 = label2rgb(L2,'jet',[1 1 1], 'shuffle');
%%
struct1  = regionprops(L1, 'centroid', 'PixelIdxList');
centroids1 = cat(1, struct1.Centroid);
struct2  = regionprops(L2, 'centroid', 'PixelIdxList');
centroids2 = cat(1, struct2.Centroid);
%
figure;
imshow(RGB1)
set(gcf,'units','pixels','Position',[Pix_SS(1) Pix_SS(2) width height])
figure;
imshow(RGB2)
set(gcf,'units','pixels','Position',[Pix_SS(1)+width Pix_SS(2) width height])
%
figure;
clear xi1 yi1 lab1 mark1
imshow(RGB1)
[xi1,yi1,P] = impixel;
%
for ip = 1:numel(xi1)
    lab1(ip) = L1(yi1(ip),xi1(ip));
end
mark1 = centroids1(lab1,:);
hold on;
for k = 1:numel(mark1(:,1))
    plot(mark1(k,1),mark1(k,2),'.m','MarkerSize',20)
   text(mark1(k,1),mark1(k,2), sprintf('c:%d,', k)); 
end
set(gcf,'units','pixels','Position',[Pix_SS(1) Pix_SS(2) width height])
%
figure;
imshow(RGB2)
clear xi2 yi2 lab2 mark2
[xi2,yi2,P] = impixel;
%
for ip = 1:numel(xi2)
    lab2(ip) = L2(yi2(ip),xi2(ip));
end
mark2 = centroids2(lab2,:);
hold on;
for k = 1:numel(mark2(:,1))
    plot(mark2(k,1),mark2(k,2),'.m','MarkerSize',20)
   text(mark2(k,1),mark2(k,2), sprintf('c:%d,', k)); 
end
set(gcf,'units','pixels','Position',[Pix_SS(1)+width Pix_SS(2) width height])
%%
tform2to1 = fitgeotrans([mark2(:,1),mark2(:,2)],[mark1(:,1),mark1(:,2)], 'affine' );
[x2af,y2af] = transformPointsForward(tform2to1,centroids2(:,1)',centroids2(:,2)');
[Dmin,Imin] = pdist2(centroids1,[x2af',y2af'],'euclidean','Smallest',1);
Dmin = Dmin';
Imin = Imin';
%%
figure;
imshow(RGB1)
hold on
for k = 2:numel(centroids1(:,1))
    plot(centroids1(k,1),centroids1(k,2),'.m','MarkerSize',20)
   text(centroids1(k,1),centroids1(k,2), sprintf('%d', k)); 
end
set(gcf,'units','pixels','Position',[Pix_SS(1) Pix_SS(2) width height])
title('Day 1')
figure;
imshow(RGB2)
hold on
for k = 2:numel(centroids2(:,1))
    plot(centroids2(k,1),centroids2(k,2),'.m','MarkerSize',20)
   text(centroids2(k,1),centroids2(k,2), sprintf('%d,%d', k, Imin(k,1))); 
end
title('Day 2 with day 1 aligned')

%%
track12(:,1) = Imin(:,1);
track12(:,2) = 1:numel(centroids2(:,1));

%% relabel day 2 label matrix
L2relab = zeros(size(L2));
L1relab = zeros(size(L1));
for k= 2:numel(struct2)
   kth_object_idx_list = struct2(k).PixelIdxList;
    L2relab(kth_object_idx_list) = Imin(k,1);
    try
    kth_object_idx_list1 = struct1(Imin(k,1)).PixelIdxList;
    L1relab(kth_object_idx_list1) = Imin(k,1);
    catch
    end
  
end
%
figure;
imshow(label2rgb(L1relab,'jet',[1 1 1], 'shuffle'))
hold on
for k = 2:numel(centroids1(:,1))
    plot(centroids1(k,1),centroids1(k,2),'.m','MarkerSize',20)
 
end
title('Day 1 relabelled ')

figure;
imshow(label2rgb(L2relab,'jet',[1 1 1], 'shuffle'))
hold on
for k = 2:numel(centroids2(:,1))
    plot(centroids2(k,1),centroids2(k,2),'.m','MarkerSize',20)
   text(centroids2(k,1),centroids2(k,2), sprintf('%d,%d', k, Imin(k,1))); 
end
title('Day 2 with day 1 aligned')
end


